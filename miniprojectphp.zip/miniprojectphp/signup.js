var password;
var confirm-password;
if(password==confirm-password)
alert("Signed up Successfully");
    