<?php
$con = mysqli_connect('localhost','root','','bookrental') or die("couldn't connect");
?>